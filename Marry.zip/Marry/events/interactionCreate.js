const { Permissions } = require('discord.js');
module.exports = async (bot, interaction) => {

};