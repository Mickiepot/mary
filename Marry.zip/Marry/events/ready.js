module.exports = async (bot)=>{
    console.log(bot.user.username + ' bot is ready!')
    
	setInterval(() => {
        bot.user.setPresence({
            activities:[{
                //syncId: '31e6f8c1ff05433c',
                name: 'Санату',
                type: 2
            }]
        })
    }, 1000*60*60)
}



