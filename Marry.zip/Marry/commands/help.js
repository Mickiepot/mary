module.exports = async (bot,message,args,argsF) => {
    message.channel.send({
        embeds: [{
            color: bot.color,
            title: `Все команды бота вы можете найти на нашем сайте`,
            description:`ссылка`
        }]
    })
};
module.exports.names = ["ping", "пинг"];
