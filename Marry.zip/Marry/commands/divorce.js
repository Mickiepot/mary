module.exports = async (bot, message, args)=>{

}
module.exports.names = ["divorce"]