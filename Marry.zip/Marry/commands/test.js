module.exports = async (bot, message, args)=>{
        for(let i of bot.family.all()){
            console.log(i.data)
        }

}
module.exports.names = ["test"]