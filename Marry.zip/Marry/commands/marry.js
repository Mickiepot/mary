module.exports = async (bot, message, args)=>{
    //проверки
    if(bot.family.get(`${message.member.id}.pair`) !== 0){
        return message.reply({
            embeds:[{
                color:bot.color,
                title:"У вас уже есть партнер!"
            }]
        })
    }
    const futurePair = message.mentions.members.first() ? message.mentions.members.first() : undefined
    if(!futurePair){
        return message.reply({
            embeds:[{
                color:bot.color,
                title: "Укажите партнера"
            }]
        })
    }
    if(futurePair.id === message.member.id){
        message.reply({
            embeds:[{
                color:bot.color,
                title:"Ну задумка интересная...."
            }]
        })
    }
    if(futurePair.user.bot){
        if(futurePair.id === bot.application.id){
            return message.reply({
                embeds:[{
                    color:bot.color,
                    title:"Мне это льстит, но увы, я откажусь"
                }]
            })
        }
        return message.reply({
            embeds:[{
                color: bot.color,
                title:"Сомневаюсь, что он сможет принять предложение"
            }]
        })
    }
 // предложение руки и сердца
    const msg = await message.channel.send({
        embeds:[{
            color:bot.color,
            title: "Предложение руки и сердца",
            description:`**${message.author} сделал предложение руки и сердца пользователю ${futurePair}**`
        }],
        components:[{
            type: 'ACTION_ROW',
            components: [
                {
                    type: 'BUTTON', //Это кнопочка
                    label: ' ', //Это имя кнопочки
                    customId: 'okey', //Это ID кнопочки
                    style: 'SECONDARY', //Стиль кнопочки
                    emoji: "✅", //Эмоджи кнопочки
                    disabled: false //Включена ли кнопочка
                },
                {
                    type: 'BUTTON', //Это кнопочка
                    label: ' ', //Это имя кнопочки
                    customId: 'notokey', //Это ID кнопочки
                    style: 'SECONDARY', //Стиль кнопочки
                    emoji: "<:cross:962661511455727697>", //Эмоджи кнопочки
                    disabled: false //Включена ли кнопочка
                }
            ]
        }]
    })
    const collector = await msg.createMessageComponentCollector();

    collector.on('collect', interaction => {
        if(interaction.user.id !== futurePair.id){
            return interaction.reply({
                ephemeral:true,
                embeds:[{
                    color:bot.color,
                    title:"Предложение адресовано не тебе"
                }]
            })
        }
        interaction.reply({
            embeds:[{
                color:bot.color,
                title:"тест"
            }]
        })
    })
}
module.exports.names = ["marry"]